const sequelize = require('../config/db');

const User = require('./user.model');
const Course = require('./course.model');

// One-to-Many (Instructor → Courses)
User.hasMany(Course, { foreignKey: 'instructorId' });
Course.belongsTo(User, { foreignKey: 'instructorId' });

sequelize.sync({ alter: true });

module.exports = {
  sequelize,
  User,
  Course
};