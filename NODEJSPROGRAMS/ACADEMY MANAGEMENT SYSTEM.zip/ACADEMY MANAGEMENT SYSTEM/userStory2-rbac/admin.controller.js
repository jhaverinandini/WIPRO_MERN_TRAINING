const { User, Course } = require('../models');

exports.dashboard = (req, res) => {
  res.render('adminDashboard');
};

exports.showCreateInstructor = (req, res) => {
  res.render('createInstructor');
};

exports.createInstructor = async (req, res) => {
  const { username, password } = req.body;

  await User.create({
    username,
    password,
    role: 'instructor'
  });

  res.redirect('/admin/dashboard');
};

exports.showCreateCourse = async (req, res) => {
  const instructors = await User.findAll({
    where: { role: 'instructor' }
  });

  res.render('createCourse', { instructors });
};

exports.createCourse = async (req, res) => {
  const { title, fee, instructorId } = req.body;

  await Course.create({
    title,
    fee,
    instructorId
  });

  res.redirect('/admin/dashboard');
};