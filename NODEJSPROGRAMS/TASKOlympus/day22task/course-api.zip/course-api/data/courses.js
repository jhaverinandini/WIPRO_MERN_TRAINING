let courses = [
  { id: 1, name: "React", duration: "30 days" }
];

module.exports = courses;