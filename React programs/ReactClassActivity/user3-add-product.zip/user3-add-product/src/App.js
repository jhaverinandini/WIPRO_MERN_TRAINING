import AddProduct from "./components/AddProduct";

function App() {
  return (
    <div>
      <h3>User Story 3 – Add Product</h3>
      <AddProduct />
    </div>
  );
}

export default App;
