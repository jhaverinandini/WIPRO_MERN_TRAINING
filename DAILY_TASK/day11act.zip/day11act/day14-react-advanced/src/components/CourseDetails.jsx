export default function CourseDetails() {
  return <p>Course Details Component Loaded</p>;
}
