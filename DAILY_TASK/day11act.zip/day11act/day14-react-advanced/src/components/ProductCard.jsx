export default function ProductCard() {
  throw new Error("Product Card crashed");
}
