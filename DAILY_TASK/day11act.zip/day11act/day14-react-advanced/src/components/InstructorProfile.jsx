export default function InstructorProfile() {
  return <p>Instructor Profile Component Loaded</p>;
}
