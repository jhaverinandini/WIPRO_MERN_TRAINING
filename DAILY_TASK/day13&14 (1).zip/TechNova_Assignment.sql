
-- This file contains SQL queries for the
--    Employee Rewards and Performance System.

--    It includes:
--    - Table creation (DDL)
--    - Data insertion and updates (DML)
--    - Queries with aggregates and dates (DQL)
--    - Joins and subqueries
--    - Transactions (COMMIT / ROLLBACK)
--    - EXPLAIN results before and after indexes
--    Logs are shown in tabular format.



-- Create Database

CREATE DATABASE TechNovaDB;
USE TechNovaDB;


   -- TABLE CREATION
  

CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) UNIQUE,
    Location VARCHAR(50)
);

CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(50),
    Gender CHAR(1),
    DOB DATE,
    HireDate DATE,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(50),
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating INT CHECK (Rating BETWEEN 1 AND 5),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);


   -- DATA INSERTION
   

INSERT INTO Department VALUES
(101, 'IT', 'Bangalore'),
(102, 'HR', 'Delhi'),
(103, 'Finance', 'Mumbai'),
(104, 'Marketing', 'Pune'),
(105, 'Support', 'Chennai');

INSERT INTO Employee VALUES
(1, 'Asha', 'F', '1990-07-12', '2018-06-10', 101),
(2, 'Raj', 'M', '1988-04-09', '2020-03-22', 102),
(3, 'Neha', 'F', '1995-01-15', '2021-08-05', 101),
(4, 'Kunal', 'M', '1992-11-20', '2019-09-12', 103),
(5, 'Priya', 'F', '1997-03-18', '2022-01-10', 104);

INSERT INTO Project VALUES
(201, 'ERP System', 101, '2020-01-01', '2021-12-31'),
(202, 'HR Portal', 102, '2021-02-01', '2022-06-30'),
(203, 'Accounting App', 103, '2019-05-01', '2020-11-30'),
(204, 'Ad Campaign', 104, '2022-03-01', '2022-12-31'),
(205, 'Helpdesk Tool', 105, '2021-07-01', '2023-01-31');

INSERT INTO Performance VALUES
(1, 201, 4, '2021-06-15'),
(2, 202, 5, '2022-04-20'),
(3, 201, 3, '2022-09-10'),
(4, 203, 4, '2020-10-05'),
(5, 204, 5, '2022-12-01');

INSERT INTO Reward VALUES
(1, '2023-01-01', 2500),
(2, '2023-02-01', 1800),
(3, '2023-03-01', 900),
(4, '2023-01-01', 3000),
(5, '2023-04-01', 2200);

DELETE FROM Reward WHERE RewardAmount < 1000;


   -- EXPLAIN BEFORE APPLYING INDEX (TABULAR LOG)
   

EXPLAIN
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance p ON e.EmpID = p.EmpID;

-- RESULT LOG:
-- +----+-------------+-------+------+---------------+------+-------+-------------+
-- | id | select_type | table | type | possible_keys | key  | rows  | Extra       |
-- +----+-------------+-------+------+---------------+------+-------+-------------+
-- |  1 | SIMPLE      | e     | ALL  | NULL          | NULL | 5     |             |
-- |  1 | SIMPLE      | d     | ALL  | PRIMARY       | NULL | 5     |             |
-- |  1 | SIMPLE      | p     | ALL  | PRIMARY       | NULL | 5     |             |
-- +----+-------------+-------+------+---------------+------+-------+-------------+


   -- APPLY INDEXES


CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(DeptID);


   -- EXPLAIN AFTER APPLYING INDEX (TABULAR LOG)
 

EXPLAIN
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance p ON e.EmpID = p.EmpID;

-- RESULT LOG:
-- +----+-------------+-------+--------+---------------+-------------+------+-------------+
-- | id | select_type | table | type   | possible_keys | key         | rows | Extra       |
-- +----+-------------+-------+--------+---------------+-------------+------+-------------+
-- |  1 | SIMPLE      | e     | ref    | idx_deptid    | idx_deptid  | 3    | Using index |
-- |  1 | SIMPLE      | d     | eq_ref | PRIMARY       | PRIMARY     | 1    |             |
-- |  1 | SIMPLE      | p     | ref    | PRIMARY       | PRIMARY     | 2    |             |
-- +----+-------------+-------+--------+---------------+-------------+------+-------------+


   -- AGGREGATE QUERY WITH LOG
 

SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Department d
JOIN Employee e ON d.DeptID = e.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
GROUP BY d.DeptName;

-- RESULT LOG:
-- +-------------+-----------+
-- | DeptName    | AvgRating |
-- +-------------+-----------+
-- | IT          | 3.5       |
-- | HR          | 5.0       |
-- | Finance     | 4.0       |
-- | Marketing   | 5.0       |
-- +-------------+-----------+


   -- AGGREGATE + DATE FUNCTION WITH LOG
   

SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

-- RESULT LOG:
-- +--------------+
-- | TotalRewards |
-- +--------------+
-- | 9500         |
-- +--------------+


   -- JOIN QUERY WITH LOG
   

SELECT e.EmpName, d.DeptName, pr.ProjectName, pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project pr ON pf.ProjectID = pr.ProjectID;

-- RESULT LOG:
-- +---------+-----------+-----------------+--------+
-- | EmpName | DeptName  | ProjectName     | Rating |
-- +---------+-----------+-----------------+--------+
-- | Asha    | IT        | ERP System      | 4      |
-- | Raj     | HR        | HR Portal       | 5      |
-- | Neha    | IT        | ERP System      | 3      |
-- | Kunal   | Finance   | Accounting App  | 4      |
-- | Priya   | Marketing | Ad Campaign     | 5      |
-- +---------+-----------+-----------------+--------+
