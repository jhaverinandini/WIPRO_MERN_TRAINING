const express = require("express");
require("dotenv").config();

const sequelize = require("./models");
const Instructor = require("./models/instructor");
const Course = require("./models/course");

const app = express();
app.use(express.json());

/* ---------------- RELATIONSHIP ---------------- */

// One Instructor → Many Courses
Instructor.hasMany(Course);
Course.belongsTo(Instructor);

/* ---------------- DATABASE SYNC ---------------- */

sequelize.sync()
.then(() => {
  console.log("Database synced");
})
.catch(err => console.log(err));

/* ---------------- POST: CREATE INSTRUCTOR ---------------- */

app.post("/instructor", async (req, res) => {

  try {

    const instructor = await Instructor.create({
      name: req.body.name
    });

    res.json(instructor);

  } catch (error) {

    console.log(error);
    res.status(500).send(error.message);

  }

});

/* ---------------- POST: CREATE COURSE ---------------- */

app.post("/course", async (req, res) => {

  try {

    console.log("BODY:", req.body); // debug

    const course = await Course.create({
      title: req.body.title,
      InstructorId: req.body.instructorId
    });

    res.json(course);

  } catch (error) {

    console.log(error);
    res.status(500).send(error.message);

  }

});

/* ---------------- GET: COURSES BY INSTRUCTOR ---------------- */

app.get("/courses/:id", async (req, res) => {

  try {

    const courses = await Course.findAll({
      where: { InstructorId: req.params.id }
    });

    res.json(courses);

  } catch (error) {

    console.log(error);
    res.status(500).send(error.message);

  }

});

/* ---------------- SERVER START ---------------- */

app.listen(process.env.PORT, () => {
  console.log("Server running on port " + process.env.PORT);
});
