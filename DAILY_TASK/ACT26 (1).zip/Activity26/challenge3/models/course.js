const { DataTypes } = require("sequelize");
const sequelize = require("./index");

const Course = sequelize.define("Course", {

  title: DataTypes.STRING

}, {
  timestamps: false   
});

module.exports = Course;
