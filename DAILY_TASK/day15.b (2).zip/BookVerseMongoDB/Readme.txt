Day 8 – MongoDB Indexing, Aggregation & Atlas


User Story 1 – Indexing
- Created indexes on genre and authorId
- Used explain("executionStats") to compare performance
- Observed IXSCAN after index creation
- Dropped unnecessary index to analyze impact

User Story 2 – Aggregation
- Calculated average rating per book
- Retrieved top 3 highest-rated books
- Counted books per genre
- Found authors with more than 2 books
- Calculated total reward points per author

User Story 3 – MongoDB Atlas
- Created free M0 cluster on MongoDB Atlas
- Created BookVerseCloudDB
- Imported collections using MongoDB Compass
- Successfully connected to Atlas

---------------------------------

Tools Used:
- MongoDB Atlas
- MongoDB Compass
- MongoDB Shell

