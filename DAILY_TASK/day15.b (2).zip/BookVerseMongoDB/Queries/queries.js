// ===============================
// DATABASE
// ===============================
//use BookVerseDB;


// ===============================
// USER STORY 1 – INDEXING
// ===============================

// Explain query BEFORE index
db.Books.find({ genre: "Fantasy" })
  .explain("executionStats");

// Create indexes
db.Books.createIndex({ genre: 1 });
db.Books.createIndex({ authorId: 1 });
db.Books.createIndex({ "ratings.score": 1 });

// Explain query AFTER index
db.Books.find({ genre: "Fantasy" })
  .explain("executionStats");

// View all indexes
db.Books.getIndexes();

// Drop unnecessary index
db.Books.dropIndex({ "ratings.score": 1 });


// ===============================
// USER STORY 2 – AGGREGATION
// ===============================

// Average rating per book
db.Books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$title",
      avgRating: { $avg: "$ratings.score" }
    }
  }
]);

// Top 3 highest-rated books
db.Books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$title",
      avgRating: { $avg: "$ratings.score" }
    }
  },
  { $sort: { avgRating: -1 } },
  { $limit: 3 }
]);

// Number of books per genre
db.Books.aggregate([
  {
    $group: {
      _id: "$genre",
      totalBooks: { $sum: 1 }
    }
  }
]);

// Authors with more than 2 books
db.Books.aggregate([
  {
    $group: {
      _id: "$authorId",
      bookCount: { $sum: 1 }
    }
  },
  { $match: { bookCount: { $gt: 2 } } }
]);

// Total reward points per author
db.Books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$authorId",
      totalPoints: { $sum: "$ratings.score" }
    }
  }
]);


// ===============================
// BONUS
// ===============================

// Compound index
db.Books.createIndex({ genre: 1, publicationYear: -1 });

// Top-rated author by average score
db.Books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$authorId",
      avgScore: { $avg: "$ratings.score" }
    }
  },
  { $sort: { avgScore: -1 } },
  { $limit: 1 }
]);


// ===============================
// USER STORY 3 – ATLAS CONNECTION
// (OPTIONAL – IF USING NODE.JS)
// ===============================

/*
const { MongoClient } = require("mongodb");

const uri = "mongodb+srv://<username>:<password>@cluster0.mongodb.net/BookVerseCloudDB";

const client = new MongoClient(uri);

async function run() {
  await client.connect();
  console.log("Connected to MongoDB Atlas");
  await client.close();
}

run();
*/