const express = require("express");
const router = express.Router();

const auth = require("../middleware/auth");

let users = [
  { id: 1, name: "John" },
  { id: 2, name: "Jane" }
];

// GET all users (uses middleware)
router.get("/", auth, (req, res) => {

  res.status(200).json(users);

});

// GET user by ID
router.get("/:id", auth, (req, res) => {

  const user = users.find(
    u => u.id === parseInt(req.params.id)
  );

  if (!user) {
    return res.status(404).json({ message: "Not found" });
  }

  res.status(200).json(user);

});

module.exports = router;
