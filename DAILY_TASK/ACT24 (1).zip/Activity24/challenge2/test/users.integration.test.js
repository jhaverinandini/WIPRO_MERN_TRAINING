const request = require("supertest");
const chai = require("chai");

const expect = chai.expect;
const app = require("../server");

describe("Users API Integration Testing", () => {

  // Test middleware failure
  it("should return 401 without token", async () => {

    const res = await request(app)
      .get("/api/users");

    expect(res.status).to.equal(401);

  });

  // Test GET all users
  it("should return all users with token", async () => {

    const res = await request(app)
      .get("/api/users")
      .set("Authorization", "testtoken");

    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");

  });

  // Test GET single user success
  it("should return user by id", async () => {

    const res = await request(app)
      .get("/api/users/1")
      .set("Authorization", "testtoken");

    expect(res.status).to.equal(200);
    expect(res.body).to.have.property("name");

  });

  // Test GET user fail
  it("should return 404 if user not found", async () => {

    const res = await request(app)
      .get("/api/users/999")
      .set("Authorization", "testtoken");

    expect(res.status).to.equal(404);

  });

});
