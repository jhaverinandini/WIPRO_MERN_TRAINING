module.exports = function(req, res, next) {

  const token = req.headers["authorization"];

  // If token missing → fail
  if (!token) {
    return res.status(401).json({ message: "No token" });
  }

  // If token present → continue
  next();
};
