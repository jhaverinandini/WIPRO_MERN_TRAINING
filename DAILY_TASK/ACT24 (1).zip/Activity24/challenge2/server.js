const express = require("express");
const app = express();

const usersRoutes = require("./routes/users");

app.use(express.json());

// mount users routes
app.use("/api/users", usersRoutes);

// export app for testing
module.exports = app;
