const express = require("express");
const router = express.Router();

// simple fake data
let courses = [
  { id: 1, name: "NodeJS" },
  { id: 2, name: "React" }
];

// GET all courses
router.get("/", (req, res) => {
  res.send(courses);
});

// GET course by id
router.get("/:id", (req, res) => {
  const course = courses.find(c => c.id == req.params.id);

  if (!course) {
    return res.status(404).send("Not found");
  }

  res.send(course);
});

// POST new course
router.post("/", (req, res) => {
  const course = {
    id: courses.length + 1,
    name: req.body.name
  };

  courses.push(course);

  res.status(201).send(course);
});

module.exports = router;
