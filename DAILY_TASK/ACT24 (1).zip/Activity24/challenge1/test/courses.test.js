const request = require("supertest");
const chai = require("chai");
const expect = chai.expect;

const app = require("../server");

describe("Courses API", () => {

  it("GET all courses", async () => {
    const res = await request(app).get("/api/courses");
    expect(res.status).to.equal(200);
  });

  it("GET valid id", async () => {
    const res = await request(app).get("/api/courses/1");
    expect(res.status).to.equal(200);
  });

  it("GET invalid id", async () => {
    const res = await request(app).get("/api/courses/999");
    expect(res.status).to.equal(404);
  });

  it("POST new course", async () => {
    const res = await request(app)
      .post("/api/courses")
      .send({ name: "MongoDB" });

    expect(res.status).to.equal(201);
  });

});
