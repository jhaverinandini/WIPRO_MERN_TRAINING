const request = require("supertest");
const chai = require("chai");
const expect = chai.expect;
const app = require("../server");

describe("Enrollment API", () => {

  it("Should return 400 for duplicate enrollment", async () => {
    const res = await request(app)
      .post("/api/enroll")
      .send({ userId: "user1", courseId: "C101" });

    expect(res.status).to.equal(400);
  });

});