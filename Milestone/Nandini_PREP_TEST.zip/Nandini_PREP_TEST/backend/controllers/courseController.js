const Course = require("../models/Course");

exports.createCourse = async (req, res, next) => {
  try {
    const { courseId, title, category, price } = req.body;

    if (!courseId || !title || !category || price === undefined) {
      return res.status(400).json({
        success: false,
        data: null,
        message: "All fields required"
      });
    }

    const course = await Course.create({ courseId, title, category, price });

    res.status(201).json({
      success: true,
      data: course,
      message: "Course created successfully"
    });

  } catch (error) {
    next(error);
  }
};

exports.getCourses = async (req, res, next) => {
  try {
    const courses = await Course.find();

    res.json({
      success: true,
      data: courses,
      message: "Courses fetched"
    });

  } catch (error) {
    next(error);
  }
};