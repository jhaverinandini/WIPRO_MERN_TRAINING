const Enrollment = require("../models/Enrollment");
const Course = require("../models/Course");

exports.enrollCourse = async (req, res, next) => {
  try {
    const { userId, courseId } = req.body;

    if (!userId || !courseId) {
      return res.status(400).json({
        success: false,
        data: null,
        message: "userId and courseId required"
      });
    }

    const course = await Course.findOne({ courseId });

    if (!course) {
      return res.status(404).json({
        success: false,
        data: null,
        message: "Course not found"
      });
    }

    const existing = await Enrollment.findOne({ userId, courseId });

    if (existing) {
      return res.status(400).json({
        success: false,
        data: null,
        message: "Duplicate enrollment"
      });
    }

    const enrollment = await Enrollment.create({ userId, courseId });

    res.status(201).json({
      success: true,
      data: enrollment,
      message: "Enrollment successful"
    });

  } catch (error) {
    next(error);
  }
};