import React from "react";

function CourseList({ courses, enroll }) {
  return (
    <div>
      <h2>Course Catalog</h2>

      {courses.map(course => (
        <div className="card" key={course.courseId}>
          <h3>{course.title}</h3>
          <p>{course.category}</p>
          <p>₹{course.price}</p>
          <button onClick={() => enroll(course.courseId)}>
            Enroll Now
          </button>
        </div>
      ))}
    </div>
  );
}

export default CourseList;