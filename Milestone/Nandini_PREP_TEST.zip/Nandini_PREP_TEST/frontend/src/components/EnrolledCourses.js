import React from "react";

function EnrolledCourses({ enrolledCourses }) {
  return (
    <div>
      <h2>Enrolled Courses</h2>

      {enrolledCourses.length === 0 ? (
        <p>No courses enrolled yet</p>
      ) : (
        <ul>
          {enrolledCourses.map(id => (
            <li key={id}>{id}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default EnrolledCourses;