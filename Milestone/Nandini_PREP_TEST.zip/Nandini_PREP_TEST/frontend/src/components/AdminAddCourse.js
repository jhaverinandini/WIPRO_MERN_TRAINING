import React, { useState } from "react";

function AdminAddCourse({ refreshCourses }) {
  const [form, setForm] = useState({
    courseId: "",
    title: "",
    category: "",
    price: ""
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:5001/api/courses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });

    const data = await res.json();

    if (res.status === 201) {
      setMessage("Course Added Successfully ✅");
      setForm({ courseId: "", title: "", category: "", price: "" });
      refreshCourses(); // re-fetch courses
    } else {
      setMessage(data.message);
    }
  };

  return (
    <div>
      <h2>Admin - Add Course</h2>

      <form onSubmit={handleSubmit}>
        <input name="courseId" value={form.courseId} placeholder="Course ID" onChange={handleChange} />
        <input name="title" value={form.title} placeholder="Title" onChange={handleChange} />
        <input name="category" value={form.category} placeholder="Category" onChange={handleChange} />
        <input name="price" value={form.price} type="number" placeholder="Price" onChange={handleChange} />
        <button type="submit">Add Course</button>
      </form>

      {message && <p>{message}</p>}
    </div>
  );
}

export default AdminAddCourse;