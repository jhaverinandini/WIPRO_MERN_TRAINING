import React, { useEffect, useState } from "react";
import AdminAddCourse from "./components/AdminAddCourse";
import CourseList from "./components/CourseList";
import EnrolledCourses from "./components/EnrolledCourses";
import "./App.css";

function App() {
  const [courses, setCourses] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchCourses = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch("http://localhost:5001/api/courses");
      const data = await res.json();
      setCourses(data.data);
    } catch (err) {
      setError("Failed to fetch courses");
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const enroll = async (courseId) => {
    try {
      const res = await fetch("http://localhost:5001/api/enroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "student1", courseId })
      });

      const data = await res.json();

      if (res.status === 201) {
        setEnrolledCourses([...enrolledCourses, courseId]);
        alert("Enrollment Successful 🎉");
      } else {
        alert(data.message);
      }

    } catch {
      alert("Network Error");
    }
  };

  return (
    <div className="container">
      <h1>SmartLearn Portal</h1>

      <AdminAddCourse refreshCourses={fetchCourses} />

      <hr />

      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}

      <CourseList courses={courses} enroll={enroll} />

      <EnrolledCourses enrolledCourses={enrolledCourses} />
    </div>
  );
}

export default App;