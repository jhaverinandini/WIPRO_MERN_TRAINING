// API service using fetch
const API_BASE_URL = 'http://localhost:5000/api';

// Helper function to handle fetch responses
const handleResponse = async (response) => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'Network error' }));
    throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
  }
  return response.json();
};

// Fetch all programs
export const fetchPrograms = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/programs`);
    return await handleResponse(response);
  } catch (error) {
    throw new Error(`Failed to fetch programs: ${error.message}`);
  }
};

// Enroll user in a program
export const enrollInProgram = async (userId, programId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/enroll`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, programId }),
    });
    return await handleResponse(response);
  } catch (error) {
    throw new Error(`Enrollment failed: ${error.message}`);
  }
};

// Get user enrollments
export const getUserEnrollments = async (userId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/enroll/${userId}`);
    return await handleResponse(response);
  } catch (error) {
    throw new Error(`Failed to fetch enrollments: ${error.message}`);
  }
};