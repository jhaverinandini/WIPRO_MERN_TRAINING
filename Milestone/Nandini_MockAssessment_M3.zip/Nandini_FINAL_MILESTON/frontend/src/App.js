import React, { useState, useEffect } from 'react';
import ProgramList from './components/ProgramList';
import EnrolledPrograms from './components/EnrolledPrograms';
import { getUserEnrollments } from './services/api';
import './App.css';

function App() {
  const [enrolledPrograms, setEnrolledPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  

  const userId = "USR101";

  useEffect(() => {
    loadUserEnrollments();
  }, []);

  const loadUserEnrollments = async () => {
    try {
      setLoading(true);
      const response = await getUserEnrollments(userId);
      if (response.success) {
        const enrollments = response.data.map(item => ({
          programId: item.enrollment.programId,
          programName: item.program.name,
          enrollment: item.enrollment,
          program: item.program
        }));
        setEnrolledPrograms(enrollments);
      }
    } catch (error) {
      console.error('Failed to load enrollments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEnrollment = (enrollmentData) => {
    setEnrolledPrograms(prev => [...prev, enrollmentData]);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>🏋️‍♂️ FitTrack</h1>
        <p>Your Personal Fitness Training Portal</p>
      </header>
      
      <main className="App-main">
        <ProgramList onEnrollment={handleEnrollment} />
        
        {!loading && (
          <EnrolledPrograms enrolledPrograms={enrolledPrograms} />
        )}
      </main>
      
      <footer className="App-footer">
        <p>&copy; 2026 FitTrack - Your Journey to Fitness Excellence</p>
      </footer>
    </div>
  );
}

export default App;
