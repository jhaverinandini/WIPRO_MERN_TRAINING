import React, { useState, useEffect } from 'react';
import { fetchPrograms, enrollInProgram } from '../services/api';
import './ProgramList.css';

const ProgramList = ({ onEnrollment }) => {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [enrollmentLoading, setEnrollmentLoading] = useState({});
  const [enrollmentMessages, setEnrollmentMessages] = useState({});
  
  // Mock user ID - in real app this would come from auth
  const userId = "USR101";

  useEffect(() => {
    loadPrograms();
  }, []);

  const loadPrograms = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetchPrograms();
      
      if (response.success) {
        setPrograms(response.data || []);
      } else {
        setError(response.message || 'Failed to fetch programs');
      }
    } catch (err) {
      setError(err.message || 'Failed to fetch programs');
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async (programId, programName) => {
    try {
      // Set loading state for this specific program
      setEnrollmentLoading(prev => ({ ...prev, [programId]: true }));
      setEnrollmentMessages(prev => ({ ...prev, [programId]: null }));

      const response = await enrollInProgram(userId, programId);
      
      if (response.success) {
        // Show success message
        setEnrollmentMessages(prev => ({ 
          ...prev, 
          [programId]: { type: 'success', text: 'Successfully enrolled!' } 
        }));
        
        // Notify parent component about successful enrollment
        if (onEnrollment) {
          onEnrollment({
            programId: programId,
            programName: programName,
            enrollment: response.data.enrollment,
            program: response.data.program
          });
        }
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setEnrollmentMessages(prev => ({ ...prev, [programId]: null }));
        }, 3000);
        
      } else {
        setEnrollmentMessages(prev => ({ 
          ...prev, 
          [programId]: { type: 'error', text: response.message || 'Enrollment failed' } 
        }));
      }
    } catch (err) {
      let errorMessage = 'Server error';
      if (err.message.includes('already enrolled')) {
        errorMessage = 'Already enrolled in this program';
      } else if (err.message.includes('not found')) {
        errorMessage = 'Program not found';
      } else if (err.message.includes('Enrollment failed')) {
        errorMessage = err.message.replace('Enrollment failed: ', '');
      }
      
      setEnrollmentMessages(prev => ({ 
        ...prev, 
        [programId]: { type: 'error', text: errorMessage } 
      }));
    } finally {
      setEnrollmentLoading(prev => ({ ...prev, [programId]: false }));
    }
  };

  if (loading) {
    return (
      <div className="program-list">
        <h2>Available Fitness Programs</h2>
        <div className="loading">Loading programs...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="program-list">
        <h2>Available Fitness Programs</h2>
        <div className="error">
          <p>Failed to fetch programs: {error}</p>
          <button onClick={loadPrograms} className="retry-btn">
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="program-list">
      <h2>Available Fitness Programs</h2>
      
      {programs.length === 0 ? (
        <div className="no-programs">
          <p>No programs available at the moment.</p>
        </div>
      ) : (
        <div className="programs-grid">
          {programs.map((program) => (
            <div key={program.programId} className="program-card">
              <div className="program-header">
                <h3>{program.name}</h3>
                <span className={`level-badge level-${program.level.toLowerCase()}`}>
                  {program.level}
                </span>
              </div>
              
              <div className="program-details">
                <p className="category">
                  <strong>Category:</strong> {program.category}
                </p>
                <p className="price">
                  <strong>Price:</strong> ₹{program.price}
                </p>
              </div>
              
              <div className="program-actions">
                <button
                  onClick={() => handleEnroll(program.programId, program.name)}
                  disabled={enrollmentLoading[program.programId]}
                  className={`enroll-btn ${enrollmentLoading[program.programId] ? 'loading' : ''}`}
                >
                  {enrollmentLoading[program.programId] ? 'Enrolling...' : 'Enroll'}
                </button>
                
                {enrollmentMessages[program.programId] && (
                  <div className={`message ${enrollmentMessages[program.programId].type}`}>
                    {enrollmentMessages[program.programId].text}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProgramList;