import React from 'react';
import './EnrolledPrograms.css';

const EnrolledPrograms = ({ enrolledPrograms }) => {
  if (!enrolledPrograms || enrolledPrograms.length === 0) {
    return (
      <div className="enrolled-programs">
        <h3>Your Enrolled Programs</h3>
        <p className="no-enrollments">You haven't enrolled in any programs yet.</p>
      </div>
    );
  }

  return (
    <div className="enrolled-programs">
      <h3>Your Enrolled Programs</h3>
      <div className="enrolled-list">
        {enrolledPrograms.map((enrollment, index) => (
          <div key={index} className="enrolled-item">
            <div className="enrolled-info">
              <h4>{enrollment.programName}</h4>
              <p className="enrolled-details">
                <span className="category">{enrollment.program?.category}</span>
                <span className="separator">•</span>
                <span className="level">{enrollment.program?.level}</span>
                <span className="separator">•</span>
                <span className="price">₹{enrollment.program?.price}</span>
              </p>
              <p className="enrolled-date">
                Enrolled on: {new Date(enrollment.enrollment?.enrolledOn).toLocaleDateString()}
              </p>
            </div>
            <div className="enrolled-status">
              <span className="status-badge">Active</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EnrolledPrograms;