# FitTrack - Personal Fitness Training Portal

A comprehensive MERN stack application for managing fitness programs and user enrollments.

## 🏗️ Project Structure

```
FitTrack/
│
├── Backend/                 # Node.js + Express + MongoDB
│   ├── models/             # Mongoose models
│   │   ├── Program.js      # Program schema
│   │   └── Enrollment.js   # Enrollment schema
│   ├── routes/             # API routes
│   │   ├── programRoutes.js
│   │   └── enrollmentRoutes.js
│   ├── middleware/         # Custom middleware
│   │   └── errorHandler.js
│   ├── tests/              # Test files
│   │   └── enrollment.test.js
│   ├── server.js           # Express server setup
│   ├── seedData.js         # Sample data seeder
│   └── .env               # Environment variables
│
└── Frontend/               # React Application
    ├── src/
    │   ├── components/     # React components
    │   │   ├── ProgramList.js
    │   │   ├── ProgramList.css
    │   │   ├── EnrolledPrograms.js
    │   │   └── EnrolledPrograms.css
    │   ├── services/       # API service layer
    │   │   └── api.js      # Fetch-based API calls
    │   ├── App.js         # Main App component
    │   └── App.css        # Global styles
    └── package.json       # Dependencies
```

## 🌐 Frontend Overview & API Integration

The FitTrack frontend is a React application that allows users to explore fitness programs, enroll in them, and view their enrolled programs. It interacts with the backend via REST APIs.

### Frontend Features

- **Program Listing:** Displays all available fitness programs fetched from the backend.
- **Enrollment:** Allows users to enroll in a program with a single click.
- **Enrolled Programs:** Shows a list of programs the user has enrolled in.
- **Feedback:** Provides real-time feedback for enrollment actions (success, already enrolled, errors).
- **Loading/Error States:** Handles loading and error UI for better user experience.

### Backend APIs Used by Frontend

1. **GET /api/programs**
   - Fetches all fitness programs.
   - Used in `ProgramList.js` to display available programs.

2. **POST /api/enroll**
   - Enrolls a user in a selected program.
   - Used in `ProgramList.js` when the user clicks "Enroll".

3. **GET /api/enroll/:userId**
   - Fetches all enrollments for a user.
   - Used in `App.js` and `EnrolledPrograms.js` to display enrolled programs.

### API Integration Details

- All API calls are handled in `src/services/api.js` using fetch.
- Unified response format expected from backend:
  ```json
  {
    "success": true|false,
    "message": "Status message",
    "data": null|object
  }
  ```

### Frontend Components

- `ProgramList.js`: Lists programs with cards and handles enrollment.
- `EnrolledPrograms.js`: Shows enrolled programs in a clean list view.
- `App.js`: Main app layout and state management.
- `services/api.js`: API utility functions for backend communication.

---

## 🚀 Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Compass)
- Git

### Backend Setup

1. **Navigate to Backend directory:**
   ```bash
   cd Backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Setup MongoDB:**
   - Make sure MongoDB is running locally on port 27017
   - Or update the `MONGODB_URI` in `.env` file

4. **Environment variables (.env):**
   ```
   MONGODB_URI=mongodb://localhost:27017/fittrack
   PORT=5000
   NODE_ENV=development
   ```

5. **Seed sample data (optional):**
   ```bash
   node seedData.js
   ```

6. **Start the server:**
   ```bash
   npm start
   ```
   Server will run on: http://localhost:5000

7. **Run tests:**
   ```bash
   npm test
   ```

### Frontend Setup

1. **Navigate to Frontend directory:**
   ```bash
   cd frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the React app:**
   ```bash
   npm start
   ```
   Application will run on: http://localhost:3000

## 📋 API Endpoints

### Programs
- `GET /api/programs` - Fetch all programs
- `POST /api/programs` - Create a new program

### Enrollment
- `POST /api/enroll` - Enroll user in a program
- `GET /api/enroll/:userId` - Get user's enrollments

### Health Check
- `GET /api/health` - API health status

## 🧪 Testing the APIs

### 1. Health Check
```bash
GET http://localhost:5000/api/health
```

### 2. Get All Programs
```bash
GET http://localhost:5000/api/programs
```

### 3. Create a Program
```bash
POST http://localhost:5000/api/programs
Content-Type: application/json

{
  "programId": "FTP001",
  "name": "Beginner Full Body Workout",
  "category": "Strength Training",
  "level": "Beginner",
  "price": 1999
}
```

### 4. Enroll in a Program
```bash
POST http://localhost:5000/api/enroll
Content-Type: application/json

{
  "userId": "USR101",
  "programId": "FTP001"
}
```

### 5. Get User Enrollments
```bash
GET http://localhost:5000/api/enroll/USR101
```

## 🎯 Features Implemented

### Backend Features ✅
- ✅ Mongoose models (Program & Enrollment)
- ✅ RESTful API endpoints
- ✅ Joi validation for requests
- ✅ Global error handling middleware
- ✅ Duplicate enrollment prevention
- ✅ Program existence validation
- ✅ Comprehensive test suite (Mocha + Chai + SuperTest)
- ✅ Unified response format

### Frontend Features ✅
- ✅ React component structure
- ✅ Program listing with cards
- ✅ Loading and error states
- ✅ Enrollment functionality
- ✅ Success/error messages
- ✅ Enrolled programs display
- ✅ Responsive design
- ✅ Fetch API integration (no axios dependency)

## 🎨 UI Features

### Program List
- Grid layout with program cards
- Level badges (Beginner, Intermediate, Advanced)
- Category and price display
- Enroll button with loading states
- Success/error message feedback

### Enrolled Programs
- Clean list view of enrolled programs
- Program details and enrollment dates
- Empty state handling

### Responsive Design
- Mobile-friendly layout
- Tablet and desktop optimization
- Accessible color scheme

## 📊 Sample Data

The application includes sample fitness programs:
- Beginner Full Body Workout (₹1999)
- Weight Loss Intensive (₹2499) 
- HIIT High Performance (₹2999)
- Yoga Mindfulness Program (₹1499)
- Lean Muscle Builder (₹2799)

## 🛠️ Tech Stack

- **Backend:** Node.js, Express.js, MongoDB, Mongoose
- **Frontend:** React.js, CSS3, Fetch API
- **Validation:** Joi
- **Testing:** Mocha, Chai, SuperTest
- **Styling:** Custom CSS with responsive design

## 🚦 Error Handling

- Validation errors (400)
- Duplicate enrollment prevention (400) 
- Program not found (404)
- Server errors (500)
- Unified error response format

## 🔄 Development Workflow

1. Start MongoDB service
2. Run backend server: `npm start`
3. Run frontend app: `npm start` 
4. Run tests: `npm test`
5. Test APIs using the provided URLs

## 📱 Sample Data & Testing

### 1️⃣ Programs Collection (programs.json)

Contains diverse fitness programs across categories and difficulty levels. ✅ Purpose: Test UI rendering, filtering, validation, and enrollment logic.

```json
[
  {
    "programId": "FTP001",
    "name": "Beginner Full Body Workout",
    "category": "Strength Training",
    "level": "Beginner",
    "price": 1999
  },
  {
    "programId": "FTP002",
    "name": "Weight Loss Intensive",
    "category": "Cardio",
    "level": "Intermediate",
    "price": 2499
  },
  {
    "programId": "FTP003",
    "name": "HIIT High Performance",
    "category": "Cardio",
    "level": "Advanced",
    "price": 2999
  },
  {
    "programId": "FTP004",
    "name": "Yoga Mindfulness Program",
    "category": "Yoga",
    "level": "Beginner",
    "price": 1499
  },
  {
    "programId": "FTP005",
    "name": "Lean Muscle Builder",
    "category": "Strength Training",
    "level": "Intermediate",
    "price": 2799
  }
]
```

### 2️⃣ Users Collection (Optional – Recommended for Testing)

Create mock users to test enrollment functionality and role-based validation. ✅ Use Cases: Valid enrollment, duplicate enrollment, error handling.

```json
[
  {
    "userId": "USR101",
    "name": "Arjun Mehta",
    "email": "arjun.mehta@example.com"
  },
  {
    "userId": "USR102",
    "name": "Sneha Verma",
    "email": "sneha.verma@example.com"
  }
]
```

### 3️⃣ Enrollment Collection (Test-Only)

Do not insert initially. Add it only when testing duplicate logic. ✅ Helps Validate: Duplicate detection, HTTP 400 response handling, prevention of duplicate user–program enrollment.

```json
[
  {
    "userId": "USR101",
    "programId": "FTP001",
    "enrolledOn": "2025-01-01T10:30:00Z"
  }
]
```

## 📬 Sample Postman Payloads

### Create Program

```http
POST /api/programs
Content-Type: application/json

{
  "programId": "FTP006",
  "name": "Athletic Conditioning",
  "category": "Sports Training",
  "level": "Advanced",
  "price": 3499
}
```

### Enrollment Request

```http
POST /api/enroll
Content-Type: application/json

{
  "userId": "USR101",
  "programId": "FTP003"
}
```