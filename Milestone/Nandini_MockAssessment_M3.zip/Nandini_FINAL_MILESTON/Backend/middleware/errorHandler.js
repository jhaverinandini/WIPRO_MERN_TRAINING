const errorHandler = (err, req, res, next) => {
  console.error(err.stack);

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const errors = err.errors && Object.keys(err.errors).length > 0 
      ? Object.values(err.errors).map(val => val.message) 
      : [err.message || 'Validation error'];
    return res.status(400).json({
      success: false,
      message: errors.join(', '),
      data: null
    });
  }

  // Mongoose duplicate key error
  if (err.code === 11000) {
    let message = 'Duplicate field value entered';
    if (err.keyPattern && err.keyPattern.programId) {
      message = 'Program with this ID already exists';
    } else if (err.keyPattern && err.keyPattern.userId && err.keyPattern.programId) {
      message = 'User is already enrolled in this program';
    }
    return res.status(400).json({
      success: false,
      message,
      data: null
    });
  }

  // Mongoose CastError
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: 'Invalid data format',
      data: null
    });
  }

  // Joi validation error
  if (err.isJoi) {
    const message = err.details && err.details[0] && err.details[0].message 
      ? err.details[0].message 
      : err.message || 'Validation error';
    return res.status(400).json({
      success: false,
      message: message,
      data: null
    });
  }

  // Default error
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    data: null
  });
};

module.exports = errorHandler;