const chai = require('chai');
const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../server');
const Program = require('../models/Program');
const Enrollment = require('../models/Enrollment');

const { expect } = chai;

describe('Enrollment API Tests', function () {
    let testProgram;

    // Setup test data before all tests
    before(async function () {
        this.timeout(10000);

        // Clear test database
        await Program.deleteMany({});
        await Enrollment.deleteMany({});

        // Create a test program
        testProgram = await Program.create({
            programId: 'TEST001',
            name: 'Test Workout Program',
            category: 'Test Category',
            level: 'Beginner',
            price: 999
        });
    });

    // Clean up after all tests
    after(async function () {
        await Program.deleteMany({});
        await Enrollment.deleteMany({});
    });

    describe('POST /api/enroll', function () {

        it('should successfully enroll a user in a program - 201', async function () {
            const enrollmentData = {
                userId: 'TEST_USER_001',
                programId: 'TEST001'
            };

            const response = await request(app)
                .post('/api/enroll')
                .send(enrollmentData)
                .expect(201);

            expect(response.body).to.have.property('success', true);
            expect(response.body).to.have.property('message', 'Enrollment successful');
            expect(response.body.data).to.have.property('enrollment');
            expect(response.body.data).to.have.property('program');
            expect(response.body.data.enrollment).to.have.property('userId', 'TEST_USER_001');
            expect(response.body.data.enrollment).to.have.property('programId', 'TEST001');
        });

        it('should prevent duplicate enrollment - 400', async function () {
            const enrollmentData = {
                userId: 'TEST_USER_001',
                programId: 'TEST001'
            };

            const response = await request(app)
                .post('/api/enroll')
                .send(enrollmentData)
                .expect(400);

            expect(response.body).to.have.property('success', false);
            expect(response.body).to.have.property('message', 'User is already enrolled in this program');
            expect(response.body).to.have.property('data', null);
        });

        it('should return 404 for non-existent program', async function () {
            const enrollmentData = {
                userId: 'TEST_USER_002',
                programId: 'NONEXISTENT'
            };

            const response = await request(app)
                .post('/api/enroll')
                .send(enrollmentData)
                .expect(404);

            expect(response.body).to.have.property('success', false);
            expect(response.body).to.have.property('message', 'Program not found');
            expect(response.body).to.have.property('data', null);
        });

        it('should return validation error for missing userId', async function () {
            const enrollmentData = {
                programId: 'TEST001'
            };

            const response = await request(app)
                .post('/api/enroll')
                .send(enrollmentData)
                .expect(400);

            expect(response.body).to.have.property('success', false);
            expect(response.body.message).to.include('User ID is required');
        });

        it('should return validation error for missing programId', async function () {
            const enrollmentData = {
                userId: 'TEST_USER_003'
            };

            const response = await request(app)
                .post('/api/enroll')
                .send(enrollmentData)
                .expect(400);

            expect(response.body).to.have.property('success', false);
            expect(response.body.message).to.include('Program ID is required');
        });
    });

    describe('GET /api/enroll/:userId', function () {

        it('should retrieve user enrollments successfully', async function () {
            const response = await request(app)
                .get('/api/enroll/TEST_USER_001')
                .expect(200);

            expect(response.body).to.have.property('success', true);
            expect(response.body).to.have.property('message', 'User enrollments retrieved successfully');
            expect(response.body.data).to.be.an('array');
            expect(response.body.data).to.have.length(1);
            expect(response.body.data[0]).to.have.property('enrollment');
            expect(response.body.data[0]).to.have.property('program');
        });

        it('should return empty array for user with no enrollments', async function () {
            const response = await request(app)
                .get('/api/enroll/USER_WITH_NO_ENROLLMENTS')
                .expect(200);

            expect(response.body).to.have.property('success', true);
            expect(response.body.data).to.be.an('array');
            expect(response.body.data).to.have.length(0);
        });
    });
});