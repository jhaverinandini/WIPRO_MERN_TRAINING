const express = require('express');
const router = express.Router();
const Joi = require('joi');
const Program = require('../models/Program');

// Joi validation schema for program creation
const programSchema = Joi.object({
  programId: Joi.string().required().trim().messages({
    'string.empty': 'Program ID is required',
    'any.required': 'Program ID is required'
  }),
  name: Joi.string().required().trim().messages({
    'string.empty': 'Program name is required',
    'any.required': 'Program name is required'
  }),
  category: Joi.string().required().trim().messages({
    'string.empty': 'Category is required',
    'any.required': 'Category is required'
  }),
  level: Joi.string().valid('Beginner', 'Intermediate', 'Advanced').required().messages({
    'any.only': 'Level must be Beginner, Intermediate, or Advanced',
    'any.required': 'Level is required'
  }),
  price: Joi.number().min(0).required().messages({
    'number.min': 'Price cannot be negative',
    'any.required': 'Price is required'
  })
});

// POST /api/programs - Add a new program
router.post('/', async (req, res, next) => {
  try {
    // Validate request body
    const { error, value } = programSchema.validate(req.body);
    if (error) {
      error.isJoi = true;
      return next(error);
    }

    // Create new program
    const program = new Program(value);
    const savedProgram = await program.save();

    res.status(201).json({
      success: true,
      message: 'Program created successfully',
      data: savedProgram
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/programs - Get all programs
router.get('/', async (req, res, next) => {
  try {
    const programs = await Program.find().sort({ createdAt: -1 });
    
    res.status(200).json({
      success: true,
      message: 'Programs retrieved successfully',
      data: programs
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;