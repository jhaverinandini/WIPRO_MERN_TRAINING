const express = require('express');
const router = express.Router();
const Joi = require('joi');
const Enrollment = require('../models/Enrollment');
const Program = require('../models/Program');

// Joi validation schema for enrollment
const enrollmentSchema = Joi.object({
  userId: Joi.string().required().trim().messages({
    'string.empty': 'User ID is required',
    'any.required': 'User ID is required'
  }),
  programId: Joi.string().required().trim().messages({
    'string.empty': 'Program ID is required',
    'any.required': 'Program ID is required'
  })
});

// POST /api/enroll - Enroll user in a program
router.post('/', async (req, res, next) => {
  try {
    // Validate request body
    const { error, value } = enrollmentSchema.validate(req.body);
    if (error) {
      error.isJoi = true;
      return next(error);
    }

    const { userId, programId } = value;

    // Check if program exists
    const program = await Program.findOne({ programId });
    if (!program) {
      return res.status(404).json({
        success: false,
        message: 'Program not found',
        data: null
      });
    }

    // Check for duplicate enrollment
    const existingEnrollment = await Enrollment.findOne({ userId, programId });
    if (existingEnrollment) {
      return res.status(400).json({
        success: false,
        message: 'User is already enrolled in this program',
        data: null
      });
    }

    // Create new enrollment
    const enrollment = new Enrollment({ userId, programId });
    const savedEnrollment = await enrollment.save();

    res.status(201).json({
      success: true,
      message: 'Enrollment successful',
      data: {
        enrollment: savedEnrollment,
        program: program
      }
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/enroll/:userId - Get user's enrollments
router.get('/:userId', async (req, res, next) => {
  try {
    const { userId } = req.params;
    
    // Get enrollments with program details
    const enrollments = await Enrollment.find({ userId });
    const enrollmentData = [];
    
    for (let enrollment of enrollments) {
      const program = await Program.findOne({ programId: enrollment.programId });
      enrollmentData.push({
        enrollment: enrollment,
        program: program
      });
    }

    res.status(200).json({
      success: true,
      message: 'User enrollments retrieved successfully',
      data: enrollmentData
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;