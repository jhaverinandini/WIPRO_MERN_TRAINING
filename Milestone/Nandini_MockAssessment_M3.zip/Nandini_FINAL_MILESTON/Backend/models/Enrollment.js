const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: [true, 'User ID is required'],
    trim: true
  },
  programId: {
    type: String,
    required: [true, 'Program ID is required'],
    trim: true
  },
  enrolledOn: {
    type: Date,
    default: Date.now
  }
});

// Create compound index to prevent duplicate enrollments
enrollmentSchema.index({ userId: 1, programId: 1 }, { unique: true });

module.exports = mongoose.model('Enrollment', enrollmentSchema);