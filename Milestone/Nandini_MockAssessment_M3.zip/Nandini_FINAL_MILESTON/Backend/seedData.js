require('dotenv').config();
const mongoose = require('mongoose');
const Program = require('./models/Program');

const samplePrograms = [
  {
    "programId": "FTP001",
    "name": "Beginner Full Body Workout",
    "category": "Strength Training",
    "level": "Beginner",
    "price": 1999
  },
  {
    "programId": "FTP002",
    "name": "Weight Loss Intensive",
    "category": "Cardio",
    "level": "Intermediate",
    "price": 2499
  },
  {
    "programId": "FTP003",
    "name": "HIIT High Performance",
    "category": "Cardio",
    "level": "Advanced",
    "price": 2999
  },
  {
    "programId": "FTP004",
    "name": "Yoga Mindfulness Program",
    "category": "Yoga",
    "level": "Beginner",
    "price": 1499
  },
  {
    "programId": "FTP005",
    "name": "Lean Muscle Builder",
    "category": "Strength Training",
    "level": "Intermediate",
    "price": 2799
  }
];

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');
    
    // Clear existing programs
    await Program.deleteMany({});
    console.log('Cleared existing programs');
    
    // Insert sample programs
    const insertedPrograms = await Program.insertMany(samplePrograms);
    console.log(`Inserted ${insertedPrograms.length} sample programs:`);
    
    insertedPrograms.forEach(program => {
      console.log(`- ${program.programId}: ${program.name} (${program.level}) - ₹${program.price}`);
    });
    
    console.log('\nDatabase seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();